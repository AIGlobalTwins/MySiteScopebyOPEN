import { Loader2 } from "lucide-react"

export default function AuthCallbackLoading() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-[#10b981]" />
        <p className="text-lg text-gray-400">Processando autenticação...</p>
      </div>
    </div>
  )
}
