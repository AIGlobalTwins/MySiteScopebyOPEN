// app/auth/callback/page.tsx
"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export default function AuthCallbackPage() {
  const router = useRouter();
  const supabase = createClientComponentClient();

  useEffect(() => {
    async function handleMagicLink() {
      try {
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSessionFromUrl({ storeSession: true });

        if (sessionError || !session) {
          console.error("Magic‑link inválido ou expirado:", sessionError);
          // volta ao login (ou mostra um erro na UI)
          router.replace("/auth?error=invalid_link");
        } else {
          // tudo OK → dashboard
          router.replace("/dashboard");
        }
      } catch (err) {
        console.error("Erro inesperado no callback:", err);
        router.replace("/auth?error=unexpected");
      }
    }

    handleMagicLink();
  }, [router, supabase]);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <p className="text-lg">A processar autenticação…</p>
    </div>
  );
}
