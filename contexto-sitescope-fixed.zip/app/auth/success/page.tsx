"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, Loader2, CheckCircle, AlertCircle, RefreshCw } from "lucide-react"
import Link from "next/link"

export default function AuthSuccessPage() {
  const [status, setStatus] = useState<"processing" | "success" | "error">("processing")
  const [message, setMessage] = useState("Processando pagamento...")
  const [errorDetails, setErrorDetails] = useState("")
  const [retryCount, setRetryCount] = useState(0)
  const router = useRouter()
  const searchParams = useSearchParams()

  const processPayment = async (sessionId: string, attempt = 1) => {
    try {
      console.log(`🔄 Tentativa ${attempt} de verificação de pagamento`)
      setMessage(`Verificando pagamento... (Tentativa ${attempt})`)

      const response = await fetch("/api/verify-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      })

      const data = await response.json()
      console.log("📊 Resposta da API:", data)

      if (response.ok && data.success && data.paid) {
        setStatus("success")
        setMessage("Pagamento confirmado! Enviando magic link...")

        // Aguardar 3 segundos e redirecionar
        setTimeout(() => {
          router.push("/auth/verify-request")
        }, 3000)
      } else {
        throw new Error(data.error || data.details || "Erro desconhecido")
      }
    } catch (error) {
      console.error(`❌ Erro na tentativa ${attempt}:`, error)

      if (attempt < 3) {
        // Retry após 2 segundos
        setTimeout(() => {
          setRetryCount(attempt)
          processPayment(sessionId, attempt + 1)
        }, 2000)
      } else {
        setStatus("error")
        setMessage("Erro ao processar pagamento após múltiplas tentativas.")
        setErrorDetails(error instanceof Error ? error.message : "Erro desconhecido")
      }
    }
  }

  const handleRetry = () => {
    const sessionId = searchParams.get("session_id")
    if (sessionId) {
      setStatus("processing")
      setRetryCount(0)
      processPayment(sessionId)
    }
  }

  useEffect(() => {
    const sessionId = searchParams.get("session_id")
    console.log("🔍 Session ID:", sessionId)

    if (!sessionId) {
      setStatus("error")
      setMessage("Session ID não encontrado na URL")
      setErrorDetails("Parâmetro session_id ausente")
      return
    }

    processPayment(sessionId)
  }, [searchParams, router])

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-12">
          <Link href="/" className="inline-flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-gradient-to-br from-[#10b981] to-[#059669] rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold">ContextoSiteScope</span>
          </Link>
        </div>

        <Card className="p-8 bg-white/5 backdrop-blur-sm border-white/10 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center"
            style={{
              backgroundColor: status === "success" ? "#10b981" : status === "error" ? "#ef4444" : "#6b7280",
            }}
          >
            {status === "processing" && <Loader2 className="w-10 h-10 animate-spin text-white" />}
            {status === "success" && <CheckCircle className="w-10 h-10 text-white" />}
            {status === "error" && <AlertCircle className="w-10 h-10 text-white" />}
          </motion.div>

          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            {status === "processing" && "Processando..."}
            {status === "success" && "Pagamento Confirmado!"}
            {status === "error" && "Erro no Pagamento"}
          </h1>

          <p className="text-gray-400 mb-6 leading-relaxed">{message}</p>

          {retryCount > 0 && status === "processing" && (
            <div className="text-sm text-yellow-400 mb-4">Tentativa {retryCount} de 3...</div>
          )}

          {status === "error" && (
            <div className="space-y-4">
              {errorDetails && (
                <div className="text-sm text-red-300 bg-red-900/20 p-3 rounded-lg">
                  <strong>Detalhes:</strong> {errorDetails}
                </div>
              )}

              <Button onClick={handleRetry} className="bg-[#10b981] hover:bg-[#059669] text-white">
                <RefreshCw className="w-4 h-4 mr-2" />
                Tentar Novamente
              </Button>

              <div className="text-sm text-gray-400">Se o problema persistir, contacte o suporte.</div>
            </div>
          )}

          {status === "success" && (
            <div className="text-sm text-[#10b981]">Redirecionando automaticamente em 3 segundos...</div>
          )}
        </Card>
      </motion.div>
    </div>
  )
}
