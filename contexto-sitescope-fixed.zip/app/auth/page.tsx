"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sparkles, Loader2, AlertCircle, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function AuthPage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const errorParam = searchParams.get("error")
    const emailParam = searchParams.get("email")

    if (emailParam) {
      setEmail(emailParam)
    }

    if (errorParam) {
      switch (errorParam) {
        case "missing_session":
          setError("Sessão de pagamento não encontrada. Tente novamente.")
          break
        case "invalid_session":
          setError("Sessão de pagamento inválida. Tente fazer um novo checkout.")
          break
        case "payment_not_confirmed":
          setError("Pagamento não foi confirmado. Verifique com seu banco.")
          break
        case "server_error":
          setError("Erro interno do servidor. Tente novamente em alguns minutos.")
          break
        case "invalid_link":
          setError("Link de autenticação inválido ou expirado.")
          break
        case "unexpected":
          setError("Erro inesperado durante a autenticação.")
          break
        default:
          setError("Ocorreu um erro. Tente novamente.")
      }
    }
  }, [searchParams])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setIsLoading(true)
    setError("")

    try {
      // Verificar se usuário existe e status da subscription
      const checkResponse = await fetch("/api/check-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })

      const checkData = await checkResponse.json()

      // The API can return either `userExists`/`hasActiveSubscription` or
      // `exists`/`paid` for backwards compatibility. We normalise them here.
      const userExists = checkData.userExists ?? checkData.exists
      const hasActiveSubscription = checkData.hasActiveSubscription ?? checkData.paid

      if (userExists) {
        if (hasActiveSubscription) {
          // Usuário existe com subscription ativa - enviar magic link
          localStorage.setItem("pendingEmail", email)

          const linkResponse = await fetch("/api/send-magic-link", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email }),
          })

          if (linkResponse.ok) {
            router.push("/auth/verify-request")
          } else {
            setError("Erro ao enviar magic link. Tente novamente.")
          }
        } else {
          // Usuário existe mas subscription expirada - ir para checkout
          router.push(`/checkout?email=${encodeURIComponent(email)}`)
        }
      } else {
        // Novo usuário - criar checkout e redirecionar para Stripe
        const checkoutResponse = await fetch("/api/create-checkout-session", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email,
            plan: "monthly", // plano padrão
          }),
        })

        const checkoutData = await checkoutResponse.json()

        if (checkoutResponse.ok && checkoutData.url) {
          // Redirecionar para Stripe
          window.location.href = checkoutData.url
        } else {
          setError("Erro ao criar sessão de pagamento. Tente novamente.")
        }
      }
    } catch (error) {
      console.error("Erro:", error)
      setError("Erro de conexão. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-12">
          <Link href="/" className="inline-flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-gradient-to-br from-[#10b981] to-[#059669] rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold">ContextoSiteScope</span>
          </Link>
        </div>

        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Entre com seu email</CardTitle>
            <CardDescription className="text-gray-400">
              Novos usuários serão redirecionados para pagamento
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-3 bg-red-900/20 border border-red-500/20 rounded-lg flex items-center space-x-2"
              >
                <AlertCircle className="w-4 h-4 text-red-400" />
                <span className="text-sm text-red-300">{error}</span>
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:border-[#10b981]"
                />
              </div>

              <Button
                type="submit"
                disabled={isLoading || !email}
                className="w-full bg-[#10b981] hover:bg-[#059669] text-white font-semibold transition-all duration-300 hover:scale-105"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processando...
                  </>
                ) : (
                  "Continuar"
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <Link
                href="/"
                className="inline-flex items-center text-sm text-gray-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Voltar ao início
              </Link>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-gray-400 mt-8">
          Processo 100% seguro. Novos usuários começam com pagamento via Stripe.
        </p>
      </motion.div>
    </div>
  )
}
