"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Mail, Sparkles, Loader2 } from "lucide-react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export default function VerifyRequestPage() {
  const [isResending, setIsResending] = useState(false)
  const [message, setMessage] = useState("")
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createClientComponentClient()

  useEffect(() => {
    const access_token = searchParams.get("access_token")
    const refresh_token = searchParams.get("refresh_token")

    if (access_token && refresh_token) {
      supabase.auth.setSession({ access_token, refresh_token }).then(() => {
        router.replace("/dashboard")
      })
    }
  }, [searchParams, supabase, router])

  const handleResend = async () => {
    setIsResending(true)
    setMessage("")

    try {
      const response = await fetch("/api/send-magic-link", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: localStorage.getItem("pendingEmail") }),
      })

      if (response.ok) {
        setMessage("Magic link reenviado com sucesso!")
      } else {
        setMessage("Erro ao reenviar. Tente novamente.")
      }
    } catch (error) {
      setMessage("Erro inesperado. Tente novamente.")
    } finally {
      setIsResending(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-12">
          <Link href="/" className="inline-flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-gradient-to-br from-[#10b981] to-[#059669] rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold">ContextoSiteScope</span>
          </Link>
        </div>

        <Card className="p-8 bg-white/5 backdrop-blur-sm border-white/10 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="w-20 h-20 bg-[#10b981]/20 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <Mail className="w-10 h-10 text-[#10b981]" />
          </motion.div>

          <h1 className="text-3xl md:text-4xl font-bold mb-4">Check Your Email</h1>

          <p className="text-gray-400 mb-8 leading-relaxed">
            Enviamos um link mágico para seu email. Clique no link para fazer login automaticamente.
          </p>

          <Button
            onClick={handleResend}
            disabled={isResending}
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10 bg-transparent"
          >
            {isResending ? (
              <div className="flex items-center space-x-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Reenviando...</span>
              </div>
            ) : (
              "Reenviar magic link"
            )}
          </Button>

          {message && (
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-4 ${message.includes("sucesso") ? "text-[#10b981]" : "text-red-400"}`}
            >
              {message}
            </motion.p>
          )}
        </Card>

        <p className="text-center text-gray-400 mt-8">Não recebeu o email? Verifique sua pasta de spam.</p>
      </motion.div>
    </div>
  )
}
