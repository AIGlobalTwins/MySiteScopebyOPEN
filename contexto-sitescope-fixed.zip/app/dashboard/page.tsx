"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart3, Globe, TrendingUp, Zap, ArrowRight, Activity } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
}

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
}

export default function DashboardPage() {
  const supabase = createClientComponentClient()
  const [loadingSession, setLoadingSession] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function handleAuthTokens() {
      try {
        // First, check if tokens are present as query parameters (e.g. ?access_token=...&refresh_token=...)
        const url = new URL(window.location.href)
        const accessToken = url.searchParams.get("access_token")
        const refreshToken = url.searchParams.get("refresh_token")

        if (accessToken && refreshToken) {
          // Persist the session in the Supabase client
          await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken })
          // Remove tokens from the URL and reload the dashboard without query params
          router.replace("/dashboard")
          return
        }

        // Fall back to handling tokens in the URL hash fragment
        if (window.location.hash.includes("access_token")) {
          const { error } = await supabase.auth.getSessionFromUrl({ storeSession: true })
          if (error) {
            console.error("Erro magic-link no dashboard:", error)
            window.location.href = "/auth?error=invalid_link"
            return
          }
        }
      } catch (err) {
        console.error("Erro ao processar tokens de autenticação:", err)
      } finally {
        setLoadingSession(false)
      }
    }

    handleAuthTokens()
  }, [supabase, router])

  if (loadingSession) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg">A processar sessão...</p>
      </div>
    )
  }

  return (
    <motion.div variants={stagger} initial="initial" animate="animate" className="space-y-8">
      {/* Welcome Section */}
      <motion.div variants={fadeInUp}>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Bem-vindo ao ContextoSiteScope</h2>
        <p className="text-gray-600 text-lg">Analise seus websites e descubra oportunidades de automação</p>
      </motion.div>

      {/* Quick Stats */}
      <motion.div variants={stagger} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            title: "Sites Analisados",
            value: "12",
            icon: Globe,
            color: "text-blue-600",
            bgColor: "bg-blue-50",
          },
          {
            title: "Automações Sugeridas",
            value: "34",
            icon: Zap,
            color: "text-[#10b981]",
            bgColor: "bg-green-50",
          },
          {
            title: "Score Médio SEO",
            value: "87%",
            icon: TrendingUp,
            color: "text-purple-600",
            bgColor: "bg-purple-50",
          },
          {
            title: "Melhorias Implementadas",
            value: "8",
            icon: Activity,
            color: "text-orange-600",
            bgColor: "bg-orange-50",
          },
        ].map((stat, index) => (
          <motion.div key={index} variants={fadeInUp}>
            <Card className="p-6 hover:shadow-lg transition-all duration-300 border-0 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-xl ${stat.bgColor}`}>                  
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Quick Actions */}
      <motion.div variants={fadeInUp} className="grid md:grid-cols-2 gap-8">
        <Card className="p-8 hover:shadow-lg transition-all duration-300 border-0 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-[#10b981]/10 rounded-xl">
              <BarChart3 className="w-8 h-8 text-[#10b981]" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Analisar Novo Website</h3>
              <p className="text-gray-600 mb-4">
                Insira a URL de um website para receber análise completa de SEO, performance e sugestões de automação.
              </p>
              <Button asChild className="bg-[#10b981] hover:bg-[#059669]">
                <Link href="/dashboard/analyzer" className="flex items-center space-x-2">
                  <span>Começar Análise</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Button>
            </div>
          </div>
        </Card>

        <Card className="p-8 hover:shadow-lg transition-all duration-300 border-0 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-blue-50 rounded-xl">
              <Globe className="w-8 h-8 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Ver Relatórios</h3>
              <p className="text-gray-600 mb-4">
                Acesse todos os relatórios de análise anteriores e acompanhe o progresso das melhorias implementadas.
              </p>
              <Button variant="outline" asChild>
                <Link href="/dashboard/reports" className="flex items-center space-x-2">
                  <span>Ver Relatórios</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Recent Activity */}
      <motion.div variants={fadeInUp}>
        <Card className="p-8 border-0 shadow-sm">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Atividade Recente</h3>

          <div className="space-y-4">
            {[
              {
                action: "Análise completa realizada",
                target: "exemplo.com",
                time: "há 2 horas",
                status: "success",
              },
              {
                action: "Sugestões de automação geradas",
                target: "meusite.pt",
                time: "há 1 dia",
                status: "info",
              },
              {
                action: "Relatório SEO exportado",
                target: "loja-online.com",
                time: "há 3 dias",
                status: "success",
              },
            ].map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0"
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      activity.status === "success" ? "bg-[#10b981]" : "bg-blue-500"
                    }`}
                  />
                  <div>
                    <p className="font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-600">{activity.target}</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </motion.div>
  )
}
