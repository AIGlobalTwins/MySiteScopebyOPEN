"use client"

import React from "react"

import type { ReactElement } from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Sparkles, CreditCard, Loader2, Check } from "lucide-react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
}

export default function CheckoutPage(): ReactElement {
  const [email, setEmail] = useState("")
  const [plan, setPlan] = useState<"monthly" | "annual">("monthly")
  const [loading, setLoading] = useState(false)
  const [isAnnual, setIsAnnual] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()

  // Get email from URL params if available
  React.useEffect(() => {
    const emailParam = searchParams.get("email")
    if (emailParam) {
      setEmail(decodeURIComponent(emailParam))
    }
  }, [searchParams])

  // Update plan when toggle changes
  React.useEffect(() => {
    setPlan(isAnnual ? "annual" : "monthly")
  }, [isAnnual])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)

    try {
      // 1) Check if user exists and has paid
      const res1 = await fetch("/api/check-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })
      const data1 = await res1.json()

      if (data1.exists && data1.paid) {
        // Send magic link immediately
        await fetch("/api/send-magic-link", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        })
        router.push("/auth/verify-request")
      } else {
        // Create checkout session
        const res2 = await fetch("/api/create-checkout-session", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, plan }),
        })
        const { url } = await res2.json()
        if (url) {
          window.location.href = url
        }
      }
    } catch (error) {
      console.error("Checkout error:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-4xl relative z-10"
      >
        <div className="text-center mb-12">
          <Link href="/" className="inline-flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-gradient-to-br from-[#10b981] to-[#059669] rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold">ContextoSiteScope</span>
          </Link>

          <h1 className="text-4xl md:text-5xl font-bold mb-4">Escolha seu Plano</h1>
          <p className="text-xl text-gray-400">Comece a analisar websites hoje mesmo</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Pricing Plans */}
          <motion.div variants={fadeInUp} className="space-y-8">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-6">Preços Simples</h2>

              {/* Toggle */}
              <div className="flex items-center justify-center space-x-4 mb-8">
                <span className={`text-lg ${!isAnnual ? "text-white" : "text-gray-400"}`}>Mensal</span>
                <Switch
                  checked={isAnnual}
                  onCheckedChange={setIsAnnual}
                  className="data-[state=checked]:bg-[#10b981]"
                />
                <span className={`text-lg ${isAnnual ? "text-white" : "text-gray-400"}`}>Anual</span>
                {isAnnual && <Badge className="bg-[#10b981] text-white">20% desconto</Badge>}
              </div>
            </div>

            <div className="grid gap-6">
              {/* Monthly Plan */}
              <Card
                className={`p-6 bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-500 ${
                  !isAnnual ? "ring-2 ring-[#10b981]" : ""
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white">Plano Mensal</h3>
                    <p className="text-gray-400">Perfeito para começar</p>
                  </div>
                  <div className="text-right">
                    <span className="text-3xl font-bold text-white">€18,85</span>
                    <span className="text-gray-400">/mês</span>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Análises ilimitadas</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Sugestões de automação</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Relatórios detalhados</span>
                  </div>
                </div>
              </Card>

              {/* Annual Plan */}
              <Card
                className={`p-6 bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-500 ${
                  isAnnual ? "ring-2 ring-[#10b981]" : ""
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white">Plano Anual</h3>
                    <p className="text-gray-400">Melhor valor</p>
                  </div>
                  <div className="text-right">
                    <span className="text-3xl font-bold text-white">€180,85</span>
                    <span className="text-gray-400">/ano</span>
                    <div className="text-sm text-[#10b981]">Economize €45,35</div>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Análises ilimitadas</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Sugestões de automação</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Relatórios detalhados</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-[#10b981]" />
                    <span>Suporte prioritário</span>
                  </div>
                </div>
              </Card>
            </div>
          </motion.div>

          {/* Checkout Form */}
          <motion.div variants={fadeInUp}>
            <Card className="p-8 bg-white/5 backdrop-blur-sm border-white/10">
              <div className="flex items-center space-x-2 mb-6">
                <CreditCard className="w-6 h-6 text-[#10b981]" />
                <h3 className="text-2xl font-bold">Finalizar Compra</h3>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                  <Input
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-12 bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:border-[#10b981]"
                  />
                </div>

                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">{isAnnual ? "Plano Anual" : "Plano Mensal"}</span>
                    <span className="font-bold text-xl">
                      {isAnnual ? "€180,85" : "€18,85"}
                      <span className="text-sm text-gray-400 font-normal">{isAnnual ? "/ano" : "/mês"}</span>
                    </span>
                  </div>
                  {isAnnual && <div className="text-sm text-[#10b981]">Você economiza €45,35 por ano!</div>}
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full h-14 bg-[#10b981] hover:bg-[#059669] text-white text-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105"
                >
                  {loading ? (
                    <div className="flex items-center space-x-2">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Processando...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-5 h-5" />
                      <span>Continuar para Pagamento</span>
                    </div>
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center text-sm text-gray-400">
                <p>Pagamento seguro processado pelo Stripe</p>
                <p className="mt-2">Cancele a qualquer momento</p>
              </div>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </div>
  )
}
