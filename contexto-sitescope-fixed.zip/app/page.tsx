"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Zap, BarChart3, Cog, Star, ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import Image from "next/image"

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.6, -0.05, 0.01, 0.99] },
}

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
}

export default function HomePage() {
  const [isAnnual, setIsAnnual] = useState(false)

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-hidden">
      {/* Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />

      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="fixed top-0 w-full z-50 backdrop-blur-xl bg-[#0a0a0a]/80 border-b border-white/5"
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-[#10b981] to-[#059669] rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">MySiteScope</span>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="#how-it-works" className="text-gray-300 hover:text-white transition-colors">
              How it works
            </Link>
            <Link href="#pricing" className="text-gray-300 hover:text-white transition-colors">
              Pricing
            </Link>
            <Link href="/auth" className="text-gray-300 hover:text-white transition-colors">
              Sign In
            </Link>
          </nav>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div variants={stagger} initial="initial" animate="animate" className="space-y-8">
            <motion.h1 variants={fadeInUp} className="text-6xl md:text-7xl font-bold leading-tight tracking-tight">
              Analisa Qualquer Website e
              <br />
              <span className="bg-gradient-to-r from-[#10b981] to-[#059669] bg-clip-text text-transparent">
              Automatiza
              </span>
              <br />
             
            </motion.h1>

            <motion.p
              variants={fadeInUp}
              className="text-xl md:text-2xl text-gray-400 max-w-xl mx-auto leading-relaxed"
            >
              Análise inteligente que identifica oportunidades de automação e otimização de qualquer website
            </motion.p>

            <motion.div variants={fadeInUp} className="pt-8">
              <Button
                asChild
                size="lg"
                className="bg-[#10b981] hover:bg-[#059669] text-white px-12 py-6 text-lg font-semibold rounded-2xl transition-all duration-300 hover:scale-105 shadow-2xl shadow-[#10b981]/25"
              >
                <Link href="/auth" className="flex items-center space-x-2">
                  <span>Começar Agora</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="how-it-works" className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">Como Funciona</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">Três passos simples para transformar qualquer website</p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-12"
          >
            {[
              {
                icon: <BarChart3 className="w-12 h-12" />,
                title: "Análise Profunda",
                description:
                  "Analizamos o teu website identificando pontos de melhoria e oportunidades de automação",
              },
              {
                icon: <Cog className="w-12 h-12" />,
                title: "Automações Inteligentes",
                description: "Geramos sugestões personalizadas de automações que podem ser implementadas no teu site",
              },
              {
                icon: <Zap className="w-12 h-12" />,
                title: "Implementação Rápida",
                description: "Fornecemos ideias e instruções prontas para implementar as melhorias sugeridas",
              },
            ].map((feature, index) => (
              <motion.div key={index} variants={fadeInUp}>
                <Card className="p-10 bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-500 group">
                  <div className="text-[#10b981] mb-6 group-hover:scale-110 transition-transform duration-300">
                    {feature.icon}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-white">{feature.title}</h3>
                  <p className="text-gray-400 text-lg leading-relaxed">{feature.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-32 px-6">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">Preços Simples</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-12">
              Escolha o plano que melhor se adequa às suas necessidades
            </p>

            {/* Toggle */}
            <div className="flex items-center justify-center space-x-4 mb-12">
              <span className={`text-lg ${!isAnnual ? "text-white" : "text-gray-400"}`}>Mensal</span>
              <Switch checked={isAnnual} onCheckedChange={setIsAnnual} className="data-[state=checked]:bg-[#10b981]" />
              <span className={`text-lg ${isAnnual ? "text-white" : "text-gray-400"}`}>Anual</span>
              {isAnnual && <Badge className="bg-[#10b981] text-white">20% desconto</Badge>}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto"
          >
            {/* Monthly Plan */}
            <Card
              className={`p-10 bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-500 ${!isAnnual ? "ring-2 ring-[#10b981]" : ""}`}
            >
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-4 text-white">Plano Mensal</h3>
                <div className="mb-6">
                  <span className="text-5xl font-bold text-white">€18,85</span>
                  <span className="text-gray-400">/mês</span>
                </div>
                <Button
                  asChild
                  className="w-full bg-[#10b981] hover:bg-[#059669] text-white py-4 text-lg font-semibold rounded-xl"
                >
                  <Link href="/checkout?plan=monthly">Começar Agora</Link>
                </Button>
              </div>
            </Card>

            {/* Annual Plan */}
            <Card
              className={`p-10 bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-500 ${isAnnual ? "ring-2 ring-[#10b981]" : ""}`}
            >
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-4 text-white">Plano Anual</h3>
                <div className="mb-6">
                  <span className="text-5xl font-bold text-white">€180,85</span>
                  <span className="text-gray-400">/ano</span>
                  <div className="text-sm text-[#10b981] mt-2">Economize €45,35</div>
                </div>
                <Button
                  asChild
                  className="w-full bg-[#10b981] hover:bg-[#059669] text-white py-4 text-lg font-semibold rounded-xl"
                >
                  <Link href="/checkout?plan=annual">Começar Agora</Link>
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">O que dizem nossos clientes</h2>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-12"
          >
            {[
              {
                name: "Maria Silva",
                role: "CEO, TechStart",
                content:
                  "O ContextoSiteScope transformou completamente nossa estratégia digital. As automações sugeridas aumentaram nossa conversão em 40%.",
                avatar: "/placeholder.svg?height=60&width=60",
              },
              {
                name: "João Santos",
                role: "Marketing Director",
                content:
                  "Ferramenta incrível! A análise detalhada nos mostrou oportunidades que nunca tínhamos considerado.",
                avatar: "/placeholder.svg?height=60&width=60",
              },
              {
                name: "Ana Costa",
                role: "Founder, EcoShop",
                content:
                  "Interface intuitiva e resultados impressionantes. Recomendo para qualquer empresa que queira otimizar seu site.",
                avatar: "/placeholder.svg?height=60&width=60",
              },
            ].map((testimonial, index) => (
              <motion.div key={index} variants={fadeInUp}>
                <Card className="p-8 bg-white/5 backdrop-blur-sm border-white/10 hover:bg-white/10 transition-all duration-500">
                  <div className="flex items-center mb-6">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-[#10b981] fill-current" />
                    ))}
                  </div>
                  <blockquote className="text-lg text-gray-300 mb-6 leading-relaxed">
                    "{testimonial.content}"
                  </blockquote>
                  <div className="flex items-center space-x-4">
                    <Image
                      src={testimonial.avatar || "/placeholder.svg"}
                      alt={testimonial.name}
                      width={48}
                      height={48}
                      className="rounded-full"
                    />
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-gray-400 text-sm">{testimonial.role}</div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-8">
            <div className="w-8 h-8 bg-gradient-to-br from-[#10b981] to-[#059669] rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">ContextoSiteScope</span>
          </div>

          <div className="flex flex-wrap justify-center space-x-8 mb-8 text-gray-400">
            <Link href="/privacy" className="hover:text-white transition-colors">
              Privacidade
            </Link>
            <Link href="/terms" className="hover:text-white transition-colors">
              Termos
            </Link>
            <Link href="/contact" className="hover:text-white transition-colors">
              Contato
            </Link>
          </div>

          <p className="text-gray-500">© 2024 ContextoSiteScope. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
