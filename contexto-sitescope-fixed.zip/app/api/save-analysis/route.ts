import { type NextRequest, NextResponse } from "next/server"
import { createSupabaseServer } from "@/lib/supabase"
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"

export async function POST(request: NextRequest) {
  try {
    const supabase = createMiddlewareClient({ req: request, res: NextResponse.next() })

    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { websiteUrl, results } = await request.json()

    if (!websiteUrl || !results) {
      return NextResponse.json({ error: "URL e resultados são obrigatórios" }, { status: 400 })
    }

    const supabaseServer = createSupabaseServer()
    const { data, error } = await supabaseServer
      .from("analyses")
      .insert({
        user_id: session.user.id,
        website_url: websiteUrl,
        results,
      })
      .select()
      .single()

    if (error) {
      console.error("Error saving analysis:", error)
      return NextResponse.json({ error: "Erro ao salvar análise" }, { status: 500 })
    }

    return NextResponse.json({ success: true, analysis: data })
  } catch (error) {
    console.error("Error saving analysis:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
