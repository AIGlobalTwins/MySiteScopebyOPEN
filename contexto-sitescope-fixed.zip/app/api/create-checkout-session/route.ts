import Stripe from "stripe";
import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2022-11-15" });
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(request: Request) {
  const { email, plan } = await request.json(); // plan: "monthly" | "annual"
  const normalized = email.toLowerCase().trim();

  // 1) garante um customer no Stripe
  // podes usar um lookup ou sempre criar e ignorar duplicates
  const customer = await stripe.customers.create({ email: normalized });

  // 2) cria session
  const priceId =
    plan === "annual"
      ? process.env.STRIPE_ANNUAL_PRICE_ID
      : process.env.STRIPE_MONTHLY_PRICE_ID;

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customer.id,
    line_items: [{ price: priceId!, quantity: 1 }],
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/checkout-success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/auth`,
    metadata: {
      email: normalized,
      plan,
    },
  });

  return NextResponse.json({ url: session.url });
}
