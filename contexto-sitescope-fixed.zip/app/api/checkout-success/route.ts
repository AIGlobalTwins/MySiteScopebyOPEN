import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get("session_id")

    console.log("🔍 Checkout Success - Session ID:", sessionId)

    if (!sessionId) {
      console.error("❌ Session ID não encontrado")
      return NextResponse.redirect(new URL("/auth?error=missing_session", request.url))
    }

    // Verificar se a sessão do Stripe é válida
    try {
      const session = await stripe.checkout.sessions.retrieve(sessionId)
      console.log("✅ Sessão Stripe válida:", session.payment_status)

      if (session.payment_status !== "paid") {
        console.error("❌ Pagamento não confirmado:", session.payment_status)
        return NextResponse.redirect(new URL("/auth?error=payment_not_confirmed", request.url))
      }

      // Redirecionar para a página de sucesso que já funciona
      return NextResponse.redirect(new URL(`/auth/success?session_id=${sessionId}`, request.url))
    } catch (stripeError) {
      console.error("❌ Erro ao verificar sessão Stripe:", stripeError)
      return NextResponse.redirect(new URL("/auth?error=invalid_session", request.url))
    }
  } catch (error) {
    console.error("❌ Erro geral no checkout-success:", error)
    return NextResponse.redirect(new URL("/auth?error=server_error", request.url))
  }
}
