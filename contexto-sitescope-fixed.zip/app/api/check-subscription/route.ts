import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(request: Request) {
  const { email } = await request.json();
  if (!email) return NextResponse.json({ error: "Email obrigatório" }, { status: 400 });

  const normalized = email.toLowerCase().trim();

  // 1) existe utilizador?
  const { data: user, error: userErr } = await supabaseAdmin
    .from("users")
    .select("id")
    .eq("email", normalized)
    .single();

  if (userErr && userErr.code !== "PGRST116") {
    return NextResponse.json({ error: userErr.message }, { status: 500 });
  }

  /*
   * For compatibility with both the checkout and auth flows we return multiple field names.
   *
   * - `exists`/`paid` were used in the original checkout logic
   * - `userExists`/`hasActiveSubscription` are expected by the auth page
   *
   * This ensures that whichever key the client expects, it will be present.
   */
  if (!user) {
    // Não existe → precisa pagar. The user does not exist, so they need to go through checkout.
    return NextResponse.json({
      exists: false,
      paid: false,
      userExists: false,
      hasActiveSubscription: false,
    });
  }

  // 2) verificar subscrição ativa
  const { data: sub } = await supabaseAdmin
    .from("subscriptions")
    .select("status")
    .eq("user_id", user.id)
    .eq("status", "active")
    .single();

  if (sub) {
    return NextResponse.json({
      exists: true,
      paid: true,
      userExists: true,
      hasActiveSubscription: true,
    });
  } else {
    return NextResponse.json({
      exists: true,
      paid: false,
      userExists: true,
      hasActiveSubscription: false,
    });
  }
}
