import { type NextRequest, NextResponse } from "next/server"
import { getStripe } from "@/lib/stripe"
import { createSupabaseServer } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  console.log("🔄 [VERIFY_PAYMENT] Iniciando verificação de pagamento")

  try {
    const { sessionId } = await request.json()
    console.log("📝 [VERIFY_PAYMENT] Session ID recebido:", sessionId)

    if (!sessionId) {
      console.error("❌ [VERIFY_PAYMENT] Session ID não fornecido")
      return NextResponse.json({ error: "Session ID é obrigatório" }, { status: 400 })
    }

    // Verificar variáveis de ambiente críticas
    const requiredEnvs = [
      "STRIPE_SECRET_KEY",
      "NEXT_PUBLIC_SUPABASE_URL",
      "SUPABASE_SERVICE_ROLE_KEY",
      "NEXT_PUBLIC_SITE_URL",
    ]

    for (const env of requiredEnvs) {
      if (!process.env[env]) {
        console.error(`❌ [VERIFY_PAYMENT] Variável de ambiente ausente: ${env}`)
        return NextResponse.json({ error: `Configuração ausente: ${env}` }, { status: 500 })
      }
    }

    console.log("✅ [VERIFY_PAYMENT] Variáveis de ambiente verificadas")

    // Recuperar sessão do Stripe
    console.log("🔄 [VERIFY_PAYMENT] Conectando ao Stripe...")
    const stripe = getStripe()

    console.log("🔄 [VERIFY_PAYMENT] Recuperando sessão do Stripe...")
    const session = await stripe.checkout.sessions.retrieve(sessionId)
    console.log("📊 [VERIFY_PAYMENT] Status do pagamento:", session.payment_status)
    console.log("📊 [VERIFY_PAYMENT] Metadata:", session.metadata)

    if (session.payment_status !== "paid") {
      console.log("⚠️ [VERIFY_PAYMENT] Pagamento não confirmado")
      return NextResponse.json({ success: true, paid: false })
    }

    const { email, plan } = session.metadata || {}
    if (!email || !plan) {
      console.error("❌ [VERIFY_PAYMENT] Metadata ausente:", { email, plan })
      return NextResponse.json({ error: "Dados de sessão inválidos" }, { status: 400 })
    }

    console.log("✅ [VERIFY_PAYMENT] Pagamento confirmado para:", email, "Plano:", plan)

    // Conectar ao Supabase
    console.log("🔄 [VERIFY_PAYMENT] Conectando ao Supabase...")
    const supabase = createSupabaseServer()

    /* ---------------------------------------------------------------------- */
    /*  1. Criar usuário no Supabase Auth                                     */
    /* ---------------------------------------------------------------------- */
    console.log("🔄 [VERIFY_PAYMENT] Criando usuário no Auth...")
    const { data: authUser, error: authErr } = await supabase.auth.admin.createUser({
      email,
      email_confirm: true,
    })

    let userId = authUser?.user?.id

    if (authErr) {
      if (authErr.message.includes("already registered")) {
        console.log("ℹ️ [VERIFY_PAYMENT] Usuário já existe, buscando ID...")
        // Buscar usuário existente
        const { data: existingUser, error: fetchErr } = await supabase.auth.admin.listUsers()
        if (fetchErr) {
          console.error("❌ [VERIFY_PAYMENT] Erro ao buscar usuário existente:", fetchErr)
          return NextResponse.json({ error: "Erro ao verificar usuário existente" }, { status: 500 })
        }

        const user = existingUser.users.find((u) => u.email === email)
        if (!user) {
          console.error("❌ [VERIFY_PAYMENT] Usuário não encontrado após criação")
          return NextResponse.json({ error: "Usuário não encontrado" }, { status: 500 })
        }
        userId = user.id
        console.log("✅ [VERIFY_PAYMENT] Usuário existente encontrado:", userId)
      } else {
        console.error("❌ [VERIFY_PAYMENT] Erro ao criar usuário:", authErr)
        return NextResponse.json({ error: "Falha ao criar usuário" }, { status: 500 })
      }
    } else {
      console.log("✅ [VERIFY_PAYMENT] Usuário criado com sucesso:", userId)
    }

    if (!userId) {
      console.error("❌ [VERIFY_PAYMENT] ID do usuário não disponível")
      return NextResponse.json({ error: "ID do usuário não disponível" }, { status: 500 })
    }

    /* ---------------------------------------------------------------------- */
    /*  2. Upsert na tabela users                                            */
    /* ---------------------------------------------------------------------- */
    console.log("🔄 [VERIFY_PAYMENT] Salvando usuário na tabela users...")
    const { error: userErr } = await supabase.from("users").upsert({
      id: userId,
      email,
      stripe_customer_id: session.customer as string,
    })

    if (userErr) {
      console.error("❌ [VERIFY_PAYMENT] Erro ao salvar usuário:", userErr)
      return NextResponse.json({ error: "Erro ao salvar usuário" }, { status: 500 })
    }
    console.log("✅ [VERIFY_PAYMENT] Usuário salvo na tabela users")

    /* ---------------------------------------------------------------------- */
    /*  3. Verificar e criar subscrição                                      */
    /* ---------------------------------------------------------------------- */
    console.log("🔄 [VERIFY_PAYMENT] Verificando subscrição existente...")
    const { data: existingSub, error: checkSubErr } = await supabase
      .from("subscriptions")
      .select("id, status")
      .eq("user_id", userId)
      .single()

    if (checkSubErr && checkSubErr.code !== "PGRST116") {
      console.error("❌ [VERIFY_PAYMENT] Erro ao verificar subscrição:", checkSubErr)
      return NextResponse.json({ error: "Erro ao verificar subscrição" }, { status: 500 })
    }

    if (!existingSub) {
      console.log("🔄 [VERIFY_PAYMENT] Criando nova subscrição...")
      const { error: subErr } = await supabase.from("subscriptions").insert({
        user_id: userId,
        status: "active",
        plan_type: plan,
        stripe_subscription_id: session.subscription as string,
      })

      if (subErr) {
        console.error("❌ [VERIFY_PAYMENT] Erro ao criar subscrição:", subErr)
        return NextResponse.json({ error: "Erro ao criar subscrição" }, { status: 500 })
      }
      console.log("✅ [VERIFY_PAYMENT] Subscrição criada com sucesso")
    } else {
      console.log("🔄 [VERIFY_PAYMENT] Atualizando subscrição existente...")
      const { error: updateErr } = await supabase
        .from("subscriptions")
        .update({
          status: "active",
          plan_type: plan,
          stripe_subscription_id: session.subscription as string,
        })
        .eq("user_id", userId)

      if (updateErr) {
        console.error("❌ [VERIFY_PAYMENT] Erro ao atualizar subscrição:", updateErr)
        return NextResponse.json({ error: "Erro ao atualizar subscrição" }, { status: 500 })
      }
      console.log("✅ [VERIFY_PAYMENT] Subscrição atualizada com sucesso")
    }

    /* ---------------------------------------------------------------------- */
    /*  4. Enviar magic link                                                 */
    /*
     * We always send the user a magic link that redirects back to our
     * authentication callback endpoint (`/auth/callback`). This keeps the
     * behaviour consistent across both new and existing users and avoids the
     * situation where a user lands directly on `/dashboard` with `access_token`
     * and `refresh_token` query parameters that our client doesn't handle. The
     * `/auth/callback` page is responsible for exchanging the tokens for a
     * session and then redirecting the user to their dashboard.
     */
    console.log("🔄 [VERIFY_PAYMENT] Enviando magic link...")
    try {
      const { error: magicErr } = await supabase.auth.signInWithOtp({
        email,
        options: {
          // Use emailRedirectTo instead of redirectTo to ensure the Supabase
          // email template sets the correct {{ .RedirectTo }} placeholder.
          emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
        },
      })

      if (magicErr) {
        console.error("⚠️ [VERIFY_PAYMENT] Erro ao enviar magic link:", magicErr)
        // Do not fail the process if the magic link fails to send
      } else {
        console.log("✅ [VERIFY_PAYMENT] Magic link enviado com sucesso")
      }
    } catch (linkErr) {
      console.error("⚠️ [VERIFY_PAYMENT] Exceção ao enviar magic link:", linkErr)
      // Do not fail the process if the magic link fails to send
    }

    console.log("🎉 [VERIFY_PAYMENT] Processo concluído com sucesso")
    return NextResponse.json({ success: true, paid: true })
  } catch (error) {
    console.error("💥 [VERIFY_PAYMENT] Erro crítico:", error)

    // Log detalhado do erro
    if (error instanceof Error) {
      console.error("💥 [VERIFY_PAYMENT] Mensagem:", error.message)
      console.error("💥 [VERIFY_PAYMENT] Stack:", error.stack)
    }

    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}
